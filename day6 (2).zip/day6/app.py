from flask import Flask, render_template, request, flash, redirect, url_for
import requests
import logging

app = Flask(__name__)
app.secret_key = "your_secret_key"  # Required for flashing messages

# Configure logging once
logging.basicConfig(
    filename="logger.log",
    filemode="a+",
    format='%(asctime)s %(message)s',
    level=logging.DEBUG
)

@app.route("/")
def home():
    return render_template("ajio_price_tracker.html")

@app.route("/output")
def output():
    return render_template("output.html")

@app.route("/productcheck", methods=['GET', 'POST'])
def productcheck():
    output = {}
    try:
        if request.method == 'POST':
            data = request.form['url']
            
            headers = {
                "User-Agent": "Mozilla/5.0"
            }

            # Handle multiple URLs (comma-separated)
            product_urls = [url.strip() for url in data.split(',')]

            logging.debug("URL(s) loaded successfully")

            for url in product_urls:
                product_code = url.split("/")[-1]
                API_URL = f"https://www.ajio.com/api/p/{product_code}"

                res = requests.get(API_URL, headers=headers)
                res.raise_for_status()  # Raise HTTP errors if any
                
                try:
                    product_details = res.json()
                    output = {
                        'Product Name': product_details['baseOptions'][0]['options'][0]['modelImage']['altText'],
                        'Product Stock': 'Available' if product_details['baseOptions'][0]['options'][0]['stock']['stockLevelStatus'] == 'inStock' else 'Out of Stock',
                        'Quantity in stock': product_details['baseOptions'][0]['options'][0]['stock']['stockLevel'],
                        'Current Price': product_details['baseOptions'][0]['options'][0]['priceData']['value'],
                        'Best Promos': [{x['code']: x['maxSavingPrice']} for x in product_details.get('potentialPromotions', [])[:3]]
                    }
                except (KeyError, ValueError) as e:
                    logging.error(f"Error processing product data: {e}")
                    flash("Error processing product data. Please check the URL or try again.")
                    return redirect(url_for('home'))

        return render_template("output.html", output=output)

    except requests.exceptions.ConnectionError:
        logging.error("Connection error. Please check your internet connection.")
        flash("Connection error. Please check your internet connection.")
        return redirect(url_for('home'))
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")
        flash("An unexpected error occurred. Please try again.")
        return redirect(url_for('home'))

if __name__ == "__main__":
    app.run(debug=True)
