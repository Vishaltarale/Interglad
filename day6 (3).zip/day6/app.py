from flask import Flask, render_template, request
from pymongo import MongoClient
import requests
import logging

app = Flask(__name__)

# Configure logging only once
logging.basicConfig(
    filename="logger.log",
    filemode="a+",
    format='%(asctime)s %(levelname)s:%(message)s',
    level=logging.DEBUG
)

@app.route("/")
def home():
    return render_template("ajio_price_tracker.html")

@app.route("/output")
def output():
    return render_template("output.html")

@app.route("/productcheck", methods=['GET', 'POST'])
def productcheck():
    output = {}
    try:
        if request.method == 'POST':
            data = request.form.get('url', '').strip()
            
            # If URL is missing
            if not data:
                logging.error("No URL provided")
                return "Please provide a valid product URL..."
            
            # Handle multiple URLs separated by whitespace
            urls = data.split()
            
            headers = {
                "User-Agent": "Mozilla/5.0",
                "Accept": "application/json",
            }

            for url in urls:
                product_code = url.split("/")[-1]
                API_URL = f"https://www.ajio.com/api/p/{product_code}"

                res = requests.get(API_URL, headers=headers)
                res.raise_for_status()  # Raise error for bad responses

                try:
                    product_details = res.json()
                except ValueError:
                    logging.error("Error decoding JSON")
                    return "Failed to decode the product data..."

                output[product_code] = {
                    'Product Name': product_details.get('baseOptions', [{}])[0].get('options', [{}])[0].get('modelImage', {}).get('altText', 'N/A'),
                    'Product Stock': 'Available' if product_details.get('baseOptions', [{}])[0].get('options', [{}])[0].get('stock', {}).get('stockLevelStatus') == 'inStock' else 'Out of Stock',
                    'Quantity in Stock': product_details.get('baseOptions', [{}])[0].get('options', [{}])[0].get('stock', {}).get('stockLevel', 0),
                    'Current Price': product_details.get('baseOptions', [{}])[0].get('options', [{}])[0].get('priceData', {}).get('value', 'N/A'),
                    'Best Promos': [{x.get('code', 'N/A'): x.get('maxSavingPrice', 0)} for x in product_details.get('potentialPromotions', [])[:3]]
                }
                client = MongoClient("mongodb+srv://user:8105272276@interglade.btjrb.mongodb.net/?retryWrites=true&w=majority&appName=Interglade",server_api=ServerApi('1'))
                db = client["ajiodb"]
                collection = db["ajiocollection"]
                collection.insert_one(output) 

            logging.info("Product details fetched successfully")
            return render_template("output.html", output=output)

        # If GET request, render the form page
        return render_template("ajio_price_tracker.html")

    except requests.exceptions.ConnectionError:
        logging.error("Connection error occurred")
        return "Connection error. Please check your internet..."
    except requests.exceptions.HTTPError as e:
        logging.error(f"HTTP Error: {e}")
        return "Failed to fetch product details. Check the URL..."
    except KeyError as e:
        logging.error(f"Key Error: {e}")
        return "Product data structure has changed..."
    except Exception as e:
        logging.error(f"Unexpected Error: {e}")
        return "An unexpected error occurred..."

if __name__ == "__main__":
    app.run(debug=True)
